// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Item.h"
#include "Explosive.generated.h"

/**
 * 
 */
UCLASS()
class FINISHEDGAME_API AExplosive : public AItem
{
	GENERATED_BODY()
public:

		AExplosive();

		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = " Explosion | Player Damage ")
		float FighterDamage;


		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = " Explosion | Jewel Damage ")
		int32 JewelDamage;


		UPROPERTY(EditAnywhere)
		FVector StartPoint;


		UPROPERTY(EditAnywhere, meta=(MakeEditWidget="true"))
		FVector EndPoint;


		/*
		Speed at which explosives move
		*/
		UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Explosion | Travel")
		float InterpSpeed;

		UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Explosion | Travel")
			float InterpTime;

		FTimerHandle InterpTimer;

		UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Explosion | Travel")
			bool bInterping;


		float Distance;




	
			virtual void OnOverlapBegin(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult &SweepResult) override;



			virtual void OnOverlapEnd(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)override;


protected://plays function when game begins.
	virtual void BeginPlay() override;

public:
	//called every Frame override original tick funcition
	virtual void Tick(float DeltaTime) override;
		
	void ToggleInterping();

		void SwapVectors(FVector& VecOne, FVector& VecTwo);

};
