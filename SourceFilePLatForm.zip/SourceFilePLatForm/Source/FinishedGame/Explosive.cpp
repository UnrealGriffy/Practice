// Fill out your copyright notice in the Description page of Project Settings.


#include "Explosive.h"
#include "TimerManager.h"
#include "MainFighter.h"

AExplosive::AExplosive()
{

	bInterping = false;

	StartPoint = FVector(0.f);
	EndPoint = FVector(0.f);
	InterpTime = 1.f;
	FighterDamage = 50.f;
	JewelDamage = 10;

}


// Called when the game starts or when spawned
void AExplosive::BeginPlay()
{
	Super::BeginPlay();


	StartPoint = GetActorLocation();
	EndPoint += StartPoint;
	bInterping = false;

	GetWorldTimerManager().SetTimer(InterpTimer, this, &AExplosive::ToggleInterping, InterpTime);

	//Getting the distance between startpoint and end point in order to switch the vectors and bring the platform back down.
	Distance = (EndPoint - StartPoint).Size();
}



void AExplosive::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (bInterping)
	{

		FVector CurrentLocation = GetActorLocation();
		FVector Interp = FMath::VInterpTo(CurrentLocation, EndPoint, DeltaTime, InterpSpeed);
		//Usiing the interp to set the actors location
		SetActorLocation(Interp);

		float DistanceTraveled = (GetActorLocation() - StartPoint).Size();
		if (Distance - DistanceTraveled <= 1.f)
		{
			ToggleInterping();
			GetWorldTimerManager().SetTimer(InterpTimer, this, &AExplosive::ToggleInterping, InterpTime);

			//Send platfrom back to start and repeat this proses
			SwapVectors(StartPoint, EndPoint);
		}

	}

}

//Makes interping true
void AExplosive::ToggleInterping()
{
	bInterping = !bInterping;
}


//Swap position of floating object
void AExplosive::SwapVectors(FVector& VecOne, FVector& VecTwo)
{
	FVector Temp = VecOne;
	VecOne = VecTwo;
	VecTwo = Temp;

}



void AExplosive::OnOverlapBegin(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult &SweepResult)
{
	Super::OnOverlapBegin(OverlappedComponent, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);

	UE_LOG(LogTemp, Warning, TEXT("Explosive::OnOverlapBegin()"));

	//check to see if player is valid
	if (OtherActor)
	{
		AMainFighter* Main = Cast<AMainFighter>(OtherActor);
		
		
		//If Player is valid we want to take away jewels and health
		if (Main)
		{
			Main->DecrementHealth(FighterDamage);
			Main->DecrementJewels(JewelDamage);
		}
	}
 }



void AExplosive::OnOverlapEnd(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	Super::OnOverlapEnd(OverlappedComponent, OtherActor, OtherComp, OtherBodyIndex);

	UE_LOG(LogTemp, Warning, TEXT("Explosive::OnOverlapEnd()"));
 }
