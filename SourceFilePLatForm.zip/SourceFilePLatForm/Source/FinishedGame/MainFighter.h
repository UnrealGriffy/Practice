// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "MainFighter.generate.h"


UENUM(BlueprintType)
enum class EMovementStatus : uint8
{
	//EMovement status Normal State
	EMS_Normal UMETA(DisplayName = "Normal "),
	EMS_Dashing UMETA(DisplayName = "Dashing"),

	EMS_MAX UMETA(DisplayName = "DefaultMAX")
};



UCLASS()
class FINISHEDGAME_API AMainFighter : public ACharacter
{

	GENERATED_BODY()
public:


	// Sets default values for this character's properties
	AMainFighter();


	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Enums")
	EMovementStatus* MovementStatus;


	/*Set the movement status and speed of dash/sprint*/
	void SetMovementStatus(EMovementStatus Status);


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Running")
	float RunningSpeed;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Dashing")
	float DashingSpeed;

	//Check to see if player is dashing
	bool bShiftKeyDown;


	/*Press down to dash*/
	void ShiftKeyDown();

	/*Release to stop dashing*/
	void ShiftKeyUp();

	/* CameraBoom is the varible for the distance  between the character & camera */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	class USpringArmComponent* CameraBoom;


	/* the follow camera */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	class UCameraComponent* FollowCam;

	/**
	If player were to use keyboard arrows this has to do with the turn horizontal
	Rate*/
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera)
	float BaseTurnRate;
	

	/**
	The at which someone looks up veritcallym the sensitivity of the azis control
	*/
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera)
	float BaseLookUpRate;

	/*
	**
	**
	Player Stats
	**
	*/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Player Stats ")
	int Lives;


	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Player Stats ")
	float MaxHealth;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite,  Category = "Player Stats ")
	float Health;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Stats ")
	float HealAmount;


	UPROPERTY(EditAnyWhere, BlueprintReadOnly, Category = "Player Stats ")
	float MaxEnergy;


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Stats ")
	float Energy;


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Stats ")
	int32 Jewels;


	/*
	**
	**
	**
	Decrement of health and coins and the function of death to fighter
	***
	**
	**
	**
	*/

	void IncrementHealth(float Amout);
	void DecrementHealth(float Amount);
	void IncrementJewels(int32 Amount);
	void DecrementJewels(int32 Amount);
	void DeathToFighter();



protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;


	/*Called forward/backwards & side to side movement input*/
	void MoveForward(float Value);

	void MoveRight(float Value);

	/*called via input turn at a given rate
	@param Rate this is a normalized rate, I.E 1.0 means 100% of desired turn rate*/
	void TurnAtRate(float Rate);

	/*called vai input look up/down at a given rate
	@param Rate this is a normalized rate, I.E 1.0 means 100% of desired to look up/down rate*/
	void LookUpAtRate(float Rate);

	FORCEINLINE class USpringArmComponent* GetCameraBoom() const { return CameraBoom; }
	FORCEINLINE class UCameraComponent* GetFollowCam() const { return FollowCam; }



};
