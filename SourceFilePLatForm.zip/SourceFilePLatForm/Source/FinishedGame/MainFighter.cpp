// Fill out your copyright notice in the Description page of Project Settings.


#include "MainFighter.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/Controller.h"
#include "Engine/World.h"
#include "Components/InputComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Public/MeshDrawShaderBindings.h"


// Sets default values
AMainFighter::AMainFighter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;


	/*Creates camera boom and pulls towrads player if there is a collision*/
	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->SetupAttachment(GetRootComponent());
	CameraBoom->TargetArmLength = 800.f; //Distance camera follows at
	CameraBoom->bUsePawnControlRotation = true; //Rotate arm based on controller

	/*Set size for capsule collision*/
	GetCapsuleComponent()->SetCapsuleSize(34.f, 89.f);

	/*Create follow camera*/
	FollowCam = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCam"));
	FollowCam->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
	FollowCam->bUsePawnControlRotation = false; //Attach cam to end of boom and let the boom adjust controller orientation

	//attaching rate to character
	BaseTurnRate = 65.f;
	BaseLookUpRate = 35.f;

	//dont rotate when controller rotate
	//effects camera only
	bUseControllerRotationYaw = false;
	bUseControllerRotationPitch = false;
	bUseControllerRotationRoll = false;

	/*Configure charcter movement
	Character moves in direction of input...
	*/
	GetCharacterMovement()->bOrientRotationToMovement = true;
	GetCharacterMovement()->RotationRate = FRotator(0.0f, 840.f, 0.0f);//At this rotation Rate
	GetCharacterMovement()->JumpZVelocity = 750.f;//Jump speed
	GetCharacterMovement()->AirControl = 0.7f;//Amount of control in the air

	
		Lives = 3;
		 MaxHealth = 100.f;
		 Health = 60.f;
		 MaxEnergy = 100.f;
		 Energy = 60.f;
		 Jewels = 20;
		 HealAmount = 25.f;

		 RunningSpeed = 650.f;
		 DashingSpeed = 1000.f;

		 bShiftKeyDown = false;

}

// Called when the game starts or when spawned
void AMainFighter::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AMainFighter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void AMainFighter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	check(PlayerInputComponent);


	/*Binding the action mapping in this case will be jumping*/
	PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &ACharacter::Jump);
	PlayerInputComponent->BindAction("Jump", IE_Released, this, &ACharacter::StopJumping);


	PlayerInputComponent->BindAction("Dash", IE_Pressed, this, &AMainFighter::ShiftKeyDown);
	PlayerInputComponent->BindAction("Dash", IE_Released, this, &AMainFighter::ShiftKeyUp);

	/*Bind buttons to move forward and right*/
	PlayerInputComponent->BindAxis("MoveForward", this, &AMainFighter::MoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &AMainFighter::MoveRight);


	/*Binds button input for look up sensitivity and look righ and left rate.*/
	PlayerInputComponent -> BindAxis("Turn", this, &APawn::AddControllerPitchInput);
	PlayerInputComponent->BindAxis("LookUp", this, &APawn::AddControllerYawInput);
	PlayerInputComponent->BindAxis("TurnRate", this, &AMainFighter::TurnAtRate);
	PlayerInputComponent->BindAxis("LookUpRate", this, &AMainFighter::LookUpAtRate);


}



void AMainFighter::MoveForward(float Value)
{

		if ((Controller != nullptr) && (Value != 0.0f))
		{
			//Find which way is forward
			const FRotator Rotation = Controller->GetControlRotation();
			const FRotator YawRotation(0.f, Rotation.Yaw, 0.f);
			/*
			FRotationMatix is created and getting yawrotation from rotation matraix
			accessing the X unit vector from the rotation matrix
			*/
			const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
			AddMovementInput(Direction, Value);


		}

}


	void AMainFighter::MoveRight(float Value)
	{
		if ((Controller != nullptr) && (Value != 0.0f))
		{
			//Find which way is forward
			const FRotator Rotation = Controller->GetControlRotation();
			const FRotator YawRotation(0.f, Rotation.Yaw, 0.f);
			/*
			FRotationMatix is created and getting yawrotation from rotation matraix
			accessing the Y  unit vector from the rotation matrix
			*/
			const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
			AddMovementInput(Direction, Value);


		}
	}

	void AMainFighter::TurnAtRate(float Rate)
	{
		AddControllerYawInput(Rate * BaseTurnRate * GetWorld()->GetDeltaSeconds());
	}

	void AMainFighter::LookUpAtRate(float Rate)
	{
		AddControllerPitchInput(Rate * BaseLookUpRate * GetWorld()->GetDeltaSeconds());
	}

	/*
	**
	**
	**
	Funtction to decrement % INCREMENT the health and jewels from fighter/player if hit by enemey or the environment
	**
	**
	**
	*/
	void AMainFighter::DecrementHealth(float Amount)
	{
		if (Health - Amount <= 0.f)
		{
			Health -= Amount;
			DeathToFighter();
		}
		else
		{
			Health -= Amount;
		}
	}

	void AMainFighter::DecrementJewels(int32 Amount)
	{
		if (Jewels - Amount <= 0)
		{
			Jewels -= Amount;
			DeathToFighter();
		}
		else
		{
			Jewels -= Amount;
		}
	}

	void AMainFighter::IncrementJewels(int32 Amount)
	{
		Jewels += Amount;
	}

	/**
	**
	**
	If the player picks up jewels if health is lower than max health the jewels will heal the player
	**
	**
	**
	*/
	void AMainFighter::IncrementHealth(float Amount)
	{
			if (Health - Amount <= MaxHealth)
			{
				Health += Amount;
				if (Health - Amount >= MaxHealth)
				{
					UE_LOG(LogTemp, Warning, TEXT("Health Is Full"));
				}
			
			}
		
	}

	void AMainFighter::DeathToFighter()
	{

	}

	void AMainFighter::SetMovementStatus(EMovementStatus Status)
	{
		MovementStatus = Status;
		if (MovementStatus == EMovementStatus::EMS_Dashing)
		{
			GetCharacterMovement()->MaxWalkSpeed = DashingSpeed;
		}
		else
		{
			GetCharacterMovement()->MaxWalkSpeed = RunningSpeed;
		}
	}


	void AMainFighter::ShiftKeyDown()
	{
		bShiftKeyDown = true;
	}

	void AMainFighter::ShiftKeyUp() 
	{
		bShiftKeyDown = false;
	}